import { db, permitRuleConfigsTable, permitApplicationsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { screenApplication, PLACEHOLDER_UNDERSERVED_CONFIG, CreatePermitApplicationResponse } from "@workspace/api-zod";

export async function readRuleConfig() {
  const [config] = await db.select().from(permitRuleConfigsTable).where(eq(permitRuleConfigsTable.id, "underserved-areas"));
  return config ? { ...config, updatedAt: config.updatedAt.toISOString() } : PLACEHOLDER_UNDERSERVED_CONFIG;
}
export type PermitRow = typeof permitApplicationsTable.$inferSelect;
export async function screenedResponse(row: PermitRow) {
  return CreatePermitApplicationResponse.parse(screenApplication({
    ...row,
    submittedAt: row.submittedAt.toISOString(),
    claimed_affordable: row.priorityClaims ? row.claimed_affordable : row.affordableHousing,
    claimed_underserved: row.priorityClaims ? row.claimed_underserved : row.underservedCommunity,
    priorityClaims: row.priorityClaims ?? undefined,
    reviewDecisions: row.reviewDecisions ?? {},
  }, await readRuleConfig()));
}
export function toValues(application: typeof CreatePermitApplicationResponse._output) {
  const { ruleChecks: _checks, ...values } = application;
  return {
    ...values, dataSource: "Prototype Submission",
    submittedAt: new Date(application.submittedAt),
    documents: application.documents.map(({ receivedAt, ...document }) =>
      receivedAt ? { ...document, receivedAt: new Date(receivedAt).toISOString() } : document,
    ),
    notes: application.notes.map(n => ({ ...n, createdAt: new Date(n.createdAt).toISOString() })),
    requiredReviewers: application.requiredReviewers ?? [],
    claimed_affordable: application.claimed_affordable ?? application.affordableHousing,
    claimed_underserved: application.claimed_underserved ?? application.underservedCommunity,
  };
}